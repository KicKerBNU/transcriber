import queue
import threading
from typing import Callable, Optional

import numpy as np
import sounddevice as sd

from mixer import mix

SAMPLE_RATE = 16_000
CHUNK_MS = 100
CHUNK_FRAMES = int(SAMPLE_RATE * CHUNK_MS / 1000)  # 1600 frames = 100ms

_VIRTUAL_AUDIO_KEYWORDS = ('blackhole', 'soundflower', 'loopback')


class AudioCapture:
    """
    Captures microphone and optional system audio (via BlackHole or similar virtual
    device), mixes both streams, and calls on_chunk(bytes) every 100ms.
    """

    def __init__(self, on_chunk: Callable[[bytes], None]) -> None:
        self._on_chunk = on_chunk
        self._running = False
        self._streams: list = []
        self._mixer_thread: Optional[threading.Thread] = None
        self._mic_q: queue.Queue = queue.Queue(maxsize=20)
        self._sys_q: Optional[queue.Queue] = None
        self._system_device: Optional[int] = self._find_system_device()

    @property
    def has_system_audio(self) -> bool:
        return self._system_device is not None

    def _find_system_device(self) -> Optional[int]:
        try:
            for idx, device in enumerate(sd.query_devices()):
                name = device['name'].lower()
                is_input = device['max_input_channels'] > 0
                is_virtual = any(k in name for k in _VIRTUAL_AUDIO_KEYWORDS)
                if is_input and is_virtual:
                    print(f'[capture] system audio device: {device["name"]} (index {idx})')
                    return idx
        except Exception as e:
            print(f'[capture] device query failed: {e}')
        return None

    def start(self) -> None:
        self._running = True

        def mic_callback(indata, frames, time_info, status):
            if self._running:
                pcm = (indata[:, 0] * 32767).astype(np.int16)
                try:
                    self._mic_q.put_nowait(pcm)
                except queue.Full:
                    pass

        mic_stream = sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype='float32',
            blocksize=CHUNK_FRAMES,
            callback=mic_callback,
        )
        self._streams.append(mic_stream)

        if self._system_device is not None:
            self._sys_q = queue.Queue(maxsize=20)

            def sys_callback(indata, frames, time_info, status):
                if self._running:
                    pcm = (indata[:, 0] * 32767).astype(np.int16)
                    try:
                        self._sys_q.put_nowait(pcm)
                    except queue.Full:
                        pass

            sys_stream = sd.InputStream(
                samplerate=SAMPLE_RATE,
                channels=1,
                dtype='float32',
                blocksize=CHUNK_FRAMES,
                device=self._system_device,
                callback=sys_callback,
            )
            self._streams.append(sys_stream)

        for s in self._streams:
            s.start()

        self._mixer_thread = threading.Thread(target=self._mix_loop, daemon=True)
        self._mixer_thread.start()
        print(f'[capture] started (system audio: {self.has_system_audio})')

    def stop(self) -> None:
        self._running = False
        for s in self._streams:
            try:
                s.stop()
                s.close()
            except Exception:
                pass
        self._streams = []
        if self._mixer_thread:
            self._mixer_thread.join(timeout=2.0)
            self._mixer_thread = None
        print('[capture] stopped')

    def _mix_loop(self) -> None:
        while self._running:
            try:
                mic = self._mic_q.get(timeout=0.5)
            except queue.Empty:
                continue

            if self._sys_q is not None:
                try:
                    sys_audio = self._sys_q.get_nowait()
                    output = mix(mic, sys_audio)
                except queue.Empty:
                    output = mic
            else:
                output = mic

            self._on_chunk(output.tobytes())
